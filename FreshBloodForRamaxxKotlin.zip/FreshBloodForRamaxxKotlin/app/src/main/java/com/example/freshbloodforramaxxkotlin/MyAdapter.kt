package com.example.freshbloodforramaxxkotlin

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView


class MyAdapter(val weatherList: List<Weather>) : RecyclerView.Adapter<MyAdapter.ViewHolder>() {

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): ViewHolder {
        val view  = LayoutInflater.from(p0.context).inflate(R.layout.item_layout ,p0, false)

        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return weatherList.size
    }

    override fun onBindViewHolder(p0: ViewHolder, p1: Int) {
        val weather: Weather = weatherList[p1]

        p0.temperatureView.text = weather.temperature.toString()
        p0.dateTimeView.text = weather.dateTime.toString()
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imageView = itemView.findViewById<ImageView>(R.id.image_view)
        val temperatureView = itemView.findViewById<TextView>(R.id.temperature_view)
        val dateTimeView = itemView.findViewById<TextView>(R.id.date_time_view)
    }
}

