package com.example.freshbloodforramaxxkotlin

import java.time.LocalDateTime
import java.util.*

data class Weather(val temperature : Int, val dateTime : LocalDateTime) {
}